<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compactible" content="ie=edge">
    <title>Verifikasi Akun</title>
</head>
<body>
    <p>
        Halo <b><?php echo e($details['username']); ?></b>!
    </p>
 
    <p>
        Anda telah melakukan registrasi akun dengan menggunakan email ini.
    </p>
 
    <p>
        Berikut adalah data anda:
    </p>
 
    <table>
        <tr>
            <td>Username</td>
            <td>:</td>
            <td><?php echo e($details['username']); ?></td>
        </tr>
 
        <tr>
            <td>Website</td>
            <td>:</td>
            <td><?php echo e($details['website']); ?></td>
        </tr>
 
        <tr>
            <td>Tanggal Register</td>
            <td>:</td>
            <td><?php echo e($details['datetime']); ?></td>
        </tr>
    </table>
 
    <center>
        <h3>
            Buka link dibawah untuk melakukan verifikasi akun.
        </h3>
 
        <b style="color : blue"><?php echo e($details['url']); ?></b>
    </center>
 
    <p>
        Terima kasih telah melakukan registrasi.
    </p>
</body>
</html><?php /**PATH D:\LaravelProject\PW9_C_11288\resources\views/mailTemplate.blade.php ENDPATH**/ ?>